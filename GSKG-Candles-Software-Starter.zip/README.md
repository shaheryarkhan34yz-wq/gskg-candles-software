# GSKG Candles Software

A Next.js starter application for two-step candle analysis.

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env.local`.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open http://localhost:3000.

## Important limitations
- The included dashboard runs in DEMO MODE with generated sample candles.
- The included prediction engine is a transparent heuristic demonstration, not a validated forecasting model.
- It does not connect to Quotex and does not claim official Quotex integration.
- To enable real-time analysis, implement a licensed market-data adapter on the server and pass validated, completed OHLC candles to `predictTwoCandles`.
- Do not put API secrets in browser code or `NEXT_PUBLIC_` variables.
- The displayed confidence is a heuristic score, not a probability of winning.
- Backtest and forward-test before any real-money use.
- License key is shown as requested; production license verification must be performed server-side. Do not treat a hard-coded frontend key as secure licensing.

## Deployment
Import this project into Vercel, set required server-side environment variables for your chosen data provider, then deploy. A real provider and credentials are required for live market data.
