"use client";
import {useMemo,useState} from "react";
import {Candle,predictTwoCandles} from "@/lib/engine";

function demoCandles():Candle[]{
  const now=Math.floor(Date.now()/1000);
  let p=1.084;
  return Array.from({length:80},(_,i)=>{
    const drift=Math.sin(i/8)*0.00012+0.000015;
    const open=p, close=open+drift+(Math.sin(i*2.3)*0.00008);
    const high=Math.max(open,close)+0.00006, low=Math.min(open,close)-0.00006;
    p=close; return {time:now-(79-i)*60,open,high,low,close,volume:100+i};
  });
}
export default function Home(){
  const [candles]=useState<Candle[]>(demoCandles);
  const [generated,setGenerated]=useState(false);
  const predictions=useMemo(()=>predictTwoCandles(candles),[candles,generated]);
  return <main className="shell">
    <header><div><div className="eyebrow">AI MARKET ANALYSIS</div><h1>GSKG <span>CANDLES</span></h1><p>Two-step advance candle analysis</p></div><div className="license">LICENSE <b>KSK34567833</b></div></header>
    <section className="notice"><b>DEMO MODE</b> — Sample candles are used. Connect a licensed, authorized market-data provider before treating any output as live market analysis. No signal guarantees a result.</section>
    <section className="toolbar"><div><small>MARKET</small><b>EUR/USD · DEMO</b></div><div><small>TIMEFRAME</small><b>1 MINUTE · SAMPLE</b></div><button onClick={()=>setGenerated(v=>!v)}>GENERATE ANALYSIS</button></section>
    <section className="grid">{predictions.map(p=><article className="signal" key={p.step}><div className="tag">STEP {p.step}</div><h2>{p.step===1?"NEXT CANDLE":"SECOND CANDLE"}</h2><div className={"direction "+(p.direction==="CALL"?"up":p.direction==="PUT"?"down":"neutral")}>{p.direction}</div><div className="confidence">{p.confidence}% <small>heuristic score</small></div><h3>Analysis factors</h3><ul>{p.reasons.map(r=><li key={r}>{r}</li>)}</ul><p className="fine">{p.disclaimer}</p></article>)}</section>
    <section className="panel"><h2>Signal engine status</h2><p>Technical indicators: EMA 9/21/50, RSI, momentum and candle-range filter.</p><p>Live feed: <b>Not connected</b></p><p>Quotex integration: <b>Not connected — no official API credentials supplied</b></p></section>
    <footer>GSKG Candles Software · Analysis and educational use only. Not financial advice.</footer>
  </main>
}
