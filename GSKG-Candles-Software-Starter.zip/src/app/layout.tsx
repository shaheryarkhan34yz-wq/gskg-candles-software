import "./style.css";
export const metadata={title:"GSKG Candles Software",description:"Two-step candle analysis dashboard"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
