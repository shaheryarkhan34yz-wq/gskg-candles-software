export type Candle = { time: number; open: number; high: number; low: number; close: number; volume?: number };
export type Prediction = {
  step: 1 | 2;
  direction: "CALL" | "PUT" | "NO TRADE";
  confidence: number;
  score: number;
  reasons: string[];
  disclaimer: string;
};

const mean = (xs: number[]) => xs.length ? xs.reduce((a,b)=>a+b,0)/xs.length : 0;
const ema = (xs: number[], period: number) => {
  if (xs.length < period) return xs[xs.length-1] ?? 0;
  const k = 2/(period+1);
  let v = mean(xs.slice(0, period));
  for (const x of xs.slice(period)) v = x*k + v*(1-k);
  return v;
};
const rsi = (xs: number[], period=14) => {
  if (xs.length <= period) return 50;
  let gains=0, losses=0;
  for(let i=xs.length-period;i<xs.length;i++){
    const d=xs[i]-xs[i-1]; if(d>0) gains+=d; else losses-=d;
  }
  if(losses===0) return 100;
  const rs=(gains/period)/(losses/period);
  return 100-(100/(1+rs));
};
const macdHistogram = (xs:number[]) => ema(xs,12)-ema(xs,26)-(ema(xs,12)-ema(xs,26)); // neutral without signal-line history
const clamp=(x:number,min:number,max:number)=>Math.max(min,Math.min(max,x));

export function validateCandles(candles:Candle[]) {
  if(candles.length < 60) return "At least 60 completed candles are required.";
  for(let i=0;i<candles.length;i++){
    const c=candles[i];
    if(!Number.isFinite(c.close)||!Number.isFinite(c.open)||c.high<c.low||c.high<Math.max(c.open,c.close)||c.low>Math.min(c.open,c.close))
      return `Invalid OHLC data at candle ${i+1}.`;
    if(i>0 && c.time<=candles[i-1].time) return "Candle timestamps must be strictly increasing.";
  }
  const last=candles[candles.length-1];
  if(Date.now()/1000-last.time > 180) return "Market data is stale. No live signal can be generated.";
  return null;
}

function scoreWindow(candles:Candle[], offset:number):{score:number;reasons:string[]} {
  // Conservative indicator ensemble; score is not a probability.
  const closes=candles.map(c=>c.close);
  const recent=closes.slice(0, closes.length-offset);
  const last=recent[recent.length-1];
  const e9=ema(recent,9), e21=ema(recent,21), e50=ema(recent,50);
  const rv=rsi(recent);
  const momentum=recent.length>5 ? (last-recent[recent.length-6])/last*100 : 0;
  const avgRange=mean(candles.slice(-14-offset,-offset||undefined).map(c=>c.high-c.low));
  const reasons:string[]=[];
  let score=0;
  if(e9>e21){score+=1;reasons.push("EMA 9 is above EMA 21");}
  else {score-=1;reasons.push("EMA 9 is below EMA 21");}
  if(e21>e50){score+=1;reasons.push("EMA 21 is above EMA 50");}
  else {score-=1;reasons.push("EMA 21 is below EMA 50");}
  if(rv>55){score+=0.7;reasons.push(`RSI momentum is bullish (${rv.toFixed(1)})`);}
  else if(rv<45){score-=0.7;reasons.push(`RSI momentum is bearish (${rv.toFixed(1)})`);}
  else reasons.push(`RSI is neutral (${rv.toFixed(1)})`);
  if(momentum>0.03){score+=0.5;reasons.push("Recent price momentum is positive");}
  else if(momentum< -0.03){score-=0.5;reasons.push("Recent price momentum is negative");}
  const lastCandle=candles[candles.length-1-offset];
  if(lastCandle && avgRange>0 && (lastCandle.high-lastCandle.low)>avgRange*2.5){
    score*=0.65; reasons.push("Unusually large candle range; confidence reduced");
  }
  return {score,reasons};
}

export function predictTwoCandles(candles:Candle[]):Prediction[] {
  const err=validateCandles(candles);
  if(err) return [1,2].map(step=>({step:step as 1|2,direction:"NO TRADE",confidence:0,score:0,reasons:[err],disclaimer:"Not a live or guaranteed trading signal."}));
  return ([1,2] as const).map(step=>{
    const {score,reasons}=scoreWindow(candles,step-1);
    const confidence=Math.round(clamp(50+Math.abs(score)*8,50,82));
    const direction=Math.abs(score)<1.25 || confidence<60 ? "NO TRADE" : score>0 ? "CALL" : "PUT";
    return {step,direction,confidence,score:Number(score.toFixed(2)),reasons,disclaimer:"Heuristic confidence score, not a calibrated probability or guarantee. Validate with backtesting and forward testing."};
  });
}
